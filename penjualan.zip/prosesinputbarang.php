<?php

include 'coneksi.php';

$nomortiket= $_POST['nomortiket'];
$nomorkursi= $_POST['nomorkursi'];
$namabus= $_POST['namabus'];
$tujuan= $_POST['tujuan'];
$waktukeberangkatan= $_POST['waktukeberangkatan'];



 mysqli_query($dbconnect, "INSERT INTO barang VALUES ( NULL, '$nomortiket','$nomorkursi','$namabus','$tujuan','$waktukeberangkatan')");

 header("location:databarang.php")
 ?>