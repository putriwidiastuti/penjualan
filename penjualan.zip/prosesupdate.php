<?php

 include 'coneksi.php';
  $id = $_POST['id'];
  $nomortiket= $_POST['nomor_tiket'];
  $nomorkursi= $_POST['nomor_kursi'];
  $namabus= $_POST['nama_bus'];
  $tujuan= $_POST['tujuan'];
  $waktukeberangkatan= $_POST['waktu_keberangkatan'];



  mysqli_query($dbconnect, "UPDATE `barang` SET `nomor_tiket`='$nomortiket' , `nomor_kursi`='$nomorkursi' , `nama_bus`='$namabus' , `tujuan`='$tujuan', `waktu_keberangkatan`='$waktukeberangkatan' WHERE `id`='$id' ");
  header("location:databarang.php");
  ?>